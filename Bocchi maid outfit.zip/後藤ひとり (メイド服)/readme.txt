「ぼっち・ざ・ろっく！」の後藤ひとりのメイド服バージョンの3Dモデルです。

◆内容物
・MMD用PMXファイル（テクスチャフォルダ付き）

◆利用規約
・改変はご自由にしていただけます。
・クレジット表記（例：「モデル制作：〇〇」など）をお願いします。

以下の行為は禁止します：
・他者や他国を侮蔑、迷惑となるような利用
・政治的、宗教的な内容を含むような利用
・著作権や各種利用規約に反する利用
・本モデルおよび改変モデルの無断再配布（※再配布希望の場合はご相談ください）
・本モデルの作者を偽る行為

※重大な規約違反が確認された場合、すべてのモデルの公開・販売を停止するなどの措置をとる可能性があります。

◆MMD版モデル（PMX）についての注意
・PMXファイルは「tex」フォルダ内のテクスチャ画像を参照しています。  
　**必ず「PMXファイル」と「texフォルダ」を同じ階層に配置してご使用ください。**

例：
　モデル名/
　├─ モデル名.pmx  
　└─ tex/  
　　　├─ face.png  
　　　└─ body.png

・PMXファイル単体では正常に表示されず、モデルが真っ白になることがありますのでご注意ください。

◆その他
・当データは予告なく変更または配布停止となることがあります。
・当データを使用することによって生じたトラブル・損害については責任を負いかねます。
・本利用規約は予告なく改定されることがあり、常に最新の規約が適用されます。

◆連絡先
ご連絡は以下のメールアドレスまでお願いいたします（★を@に変えてください）  
endroidproject3★gmail.com

--------------------------------------------------------------------------------

This is a 3D model of Hitori Gotoh from "Bocchi the Rock!" in a maid outfit version.

◆Contents
- PMX model for MMD (with texture folder)

◆Terms of Use
- You are free to modify this model.
- Please credit the author (e.g., “Model by ○○”) when using the model.

The following actions are prohibited:
- Any use that insults, discriminates, or causes trouble to others or other countries
- Use in political or religious contexts
- Use that violates copyrights or terms of use of other creators
- Redistribution of this model or any modified version without permission (Please contact the creator if you wish to distribute a modified version)
- Claiming authorship of this model

※ If a serious violation of the terms is discovered, I may suspend the distribution or sales of all models.

◆Important Notes about the PMX model (for MMD)
- The PMX file references texture images inside the “tex” folder.  
  **Make sure to place the PMX file and the “tex” folder in the same directory.**

Example:
  ModelName/
  ├─ ModelName.pmx  
  └─ tex/  
      ├─ face.png  
      └─ body.png

- If the PMX file is used without the tex folder, the model may appear completely white.

◆Additional Notes
- This model may be updated or removed without notice.
- I am not responsible for any trouble or damage caused by the use of this model.
- These terms of use are subject to change without notice. The latest version always applies.

◆Contact
Please contact me at the following email address (replace ★ with @):  
endroidproject3★gmail.com
