﻿using System.Windows;

namespace GameLauncher
{
    public partial class App : System.Windows.Application
    {
    }
}

