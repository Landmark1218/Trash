﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using WinForms = System.Windows.Forms;

namespace GameLauncher
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            ProfileNameTextBox.TextChanged += ProfileNameTextBox_TextChanged;
            FortnitePathTextBox.TextChanged += FortnitePathTextBox_TextChanged;
        }

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
                this.DragMove();
        }

        // 閉じるボタン
        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        // 
        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var processes = System.Diagnostics.Process.GetProcesses();
                foreach (var process in processes)
                {
                    if (process.ProcessName.Contains("Fortnite"))
                        process.Kill(); // フォトナ関連のタスク終了
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show($"プロセス終了時にエラーが発生しました: {ex.Message}", "エラー", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LaunchButton_Click(object sender, RoutedEventArgs e)
        {
            string folderPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Sakura Launcher");
            string filePath = Path.Combine(folderPath, "Profile.json");

            if (!File.Exists(filePath))
            {
                System.Windows.MessageBox.Show("プロファイルファイルが見つかりません。", "エラー", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            try
            {
                // jsonを読み込んでプロファイルを取得
                string json = File.ReadAllText(filePath);
                ProfileData? profileData = JsonSerializer.Deserialize<ProfileData>(json);
                if (profileData == null)
                {
                    System.Windows.MessageBox.Show("プロファイルの読み込みに失敗しました", "エラー", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }


                // プロファイル選択画面を表示
                MainScreen.Visibility = Visibility.Collapsed;
                ProfileSelectionScreen.Visibility = Visibility.Visible;

                // プロファイル選択画面にボタンを追加
                ProfileSelectionPanel.Children.Clear();  // ボタンをクリア

                foreach (var profile in profileData.Profiles)
                {
                    System.Windows.Controls.Button profileButton = new System.Windows.Controls.Button
                    {
                        Content = profile.Value.Name,
                        Width = 200,
                        Height = 50,
                        Margin = new Thickness(0, 10, 0, 0),
                        FontSize = 16,
                        Background = new SolidColorBrush(System.Windows.Media.Color.FromRgb(0, 122, 204)),
                        Foreground = Foreground = System.Windows.Media.Brushes.White

                    };

                    profileButton.Click += (s, args) =>
                    {
                        System.Windows.MessageBox.Show($"{profile.Value.Name}が選択されました。");
                        //後から書くかも
                    };

                    ProfileSelectionPanel.Children.Add(profileButton);
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show($"エラーが発生しました: {ex.Message}", "エラー", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // ディスコのリンク
        private void Discord_Click(object sender, MouseButtonEventArgs e)
        {
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
            {
                FileName = "https://discord.gg/fbKZwPWBw5",
                UseShellExecute = true
            });
        }

        // Xのリンク
        private void Twitter_Click(object sender, MouseButtonEventArgs e)
        {
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
            {
                FileName = "https://x.com/BiruFN",
                UseShellExecute = true
            });
        }

        // 設定ボタン推したらメイン画面から設定画面に切り替える
        private void SettingsButton_Click(object sender, RoutedEventArgs e)
        {
            MainScreen.Visibility = Visibility.Collapsed;
            SettingsScreen.Visibility = Visibility.Visible;
        }

        // 戻るボタンが押されたら設定画面からメイン画面に戻る
        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            SettingsScreen.Visibility = Visibility.Collapsed;
            MainScreen.Visibility = Visibility.Visible;
        }

        // 保存
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            string profileName = ProfileNameTextBox.Text;
            string path = FortnitePathTextBox.Text;

            // 入力エラー
            if (string.IsNullOrWhiteSpace(profileName) || string.IsNullOrWhiteSpace(path))
            {
                System.Windows.MessageBox.Show("すべて入力してください", "エラー", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // FortniteGameフォルダ以外の場合
            if (!path.EndsWith("FortniteGame", StringComparison.OrdinalIgnoreCase))
            {
                System.Windows.MessageBox.Show("FortniteGameフォルダを選択してください", "エラー", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            try
            {
                SaveProfileToJson(profileName, path); // プロファイル保存
                System.Windows.MessageBox.Show("保存しました", "完了", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show($"エラーが発生しました: {ex.Message}", "エラー", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // 文字消す
        private void ProfileNameTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            ProfileNameHint.Visibility = string.IsNullOrWhiteSpace(ProfileNameTextBox.Text) ? Visibility.Visible : Visibility.Collapsed;
        }

        // 文字表示切替
        private void FortnitePathTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            FortnitePathHint.Visibility = string.IsNullOrWhiteSpace(FortnitePathTextBox.Text) ? Visibility.Visible : Visibility.Collapsed;
        }
        private void BackToMainFromProfile_Click(object sender, RoutedEventArgs e)
        {
            ProfileSelectionScreen.Visibility = Visibility.Collapsed;
            MainScreen.Visibility = Visibility.Visible;
        }

        // フォルダダイアログ表示
        private void BrowseFolderButton_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new WinForms.FolderBrowserDialog();
            if (dialog.ShowDialog() == WinForms.DialogResult.OK)
            {
                FortnitePathTextBox.Text = dialog.SelectedPath; // フォルダパスをテキストボックスに設定
            }
        }

        // プロファイル保存
        private void SaveProfileToJson(string profileName, string path)
        {
            string folderPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Sakura Launcher");
            string filePath = Path.Combine(folderPath, "Profile.json");

            // ifフォルダがない
            if (!Directory.Exists(folderPath))
                Directory.CreateDirectory(folderPath);

            ProfileData profileData;

            // json読み込み、プロファイル追加
            if (File.Exists(filePath))
            {
                string json = File.ReadAllText(filePath);
                profileData = JsonSerializer.Deserialize<ProfileData>(json) ?? new ProfileData();
            }
            else
            {
                profileData = new ProfileData();
            }

            // 新しいプロファイル追加
            int index = 1;
            string newProfileKey = $"profile{index}";
            while (profileData.Profiles.ContainsKey(newProfileKey))
            {
                index++;
                newProfileKey = $"profile{index}";
            }

            profileData.Profiles[newProfileKey] = new Profile
            {
                Name = profileName,
                FilePath = path
            };

            // json保存
            string newJson = JsonSerializer.Serialize(profileData, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(filePath, newJson);
        }
    }

    // プロファイルモデル
    public class Profile
    {
        public string Name { get; set; } = string.Empty;
        public string FilePath { get; set; } = string.Empty;
    }

    // プロファイルjsonの構造
    public class ProfileData
    {
        public Dictionary<string, Profile> Profiles { get; set; } = new();
    }
}
